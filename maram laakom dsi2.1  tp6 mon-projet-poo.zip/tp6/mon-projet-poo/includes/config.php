<?php
// includes/config.php
define('DB_HOST', 'localhost');
define('DB_NAME', 'atelier');
define('DB_USER', 'dsi21admin');
define('DB_PASS', 'dsi21admin');
?>