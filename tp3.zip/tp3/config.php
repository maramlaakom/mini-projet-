<?php
// Paramètres de connexion MySQL
define('DB_HOST', 'localhost'); // Hôte (souvent localhost)
define('DB_NAME', 'atelier'); // Nom de la base de données créée
define('DB_USER', 'dsi21admin');       // Utilisateur par défaut
define('DB_PASS', 'dsi21admin');           // Mot de passe par défaut (souvent vide)
?>