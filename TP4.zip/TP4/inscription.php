<?php
// inscription.php
require 'connexion.php';
 // Inclut la connexion PDO et l'objet $pdo

// Données à insérer (simulées ou issues d'un $_POST validé)
$nom_saisi = "Alice Dupont";
$email_saisi = "alice.dupont@exemple.com";

try {
    // 1. Définir la requête avec des marqueurs nommés (:nom_user, :email_user)
    $sql = "INSERT INTO utilisateurs (nom, email) VALUES (:nom_user, :email_user)";

    // 2. Préparer la requête
    $stmt = $pdo->prepare($sql);

    // 3. Lier les valeurs aux marqueurs (on peut ajouter ici htmlspecialchars())
    $stmt->bindParam(':nom_user', $nom_saisi);
    $stmt->bindParam(':email_user', $email_saisi);
    
    // 4. Exécuter la requête
    $stmt->execute();
    
    echo "<p style='color: green;'> Nouvelle entrée créée avec succès !</p>";
    
    // Pour vérifier : affiche l'ID inséré
    echo "<p>ID inséré : " . $pdo->lastInsertId() . "</p>";

} catch (PDOException $e) {
    echo "<p style='color: red;'> Erreur lors de l'insertion : " . $e->getMessage() . "</p>";
}
?>