<?php
// logout.php
session_start(); // **NÉCESSAIRE** pour accéder à la session existante

// 1. Supprimer toutes les variables de session
$_SESSION = array(); // Bonne pratique

// 2. Détruire la session
session_destroy();

// Redirection vers la page de connexion
header('Location: login.php');
exit;
?>