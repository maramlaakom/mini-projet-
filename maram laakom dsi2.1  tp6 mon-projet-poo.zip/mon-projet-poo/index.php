<?php
require_once 'classes/Database.php';
require_once 'classes/User.php';


Database::getInstance();

User::insertUser("Charles Dubois", "charles@exemple.com");

?>
<h2>Liste des Utilisateurs (POO)</h2>

<table border="1" cellpadding="10" cellspacing="0">
    <tr><th>ID</th><th>Nom</th><th>Email</th></tr>

    <?php foreach ($utilisateurs as $user): ?>
        <tr>
            <td><?= htmlspecialchars($user['id']) ?></td>
            <td><?= htmlspecialchars($user['nom']) ?></td>
            <td><?= htmlspecialchars($user['email']) ?></td>
        </tr>
    <?php endforeach; ?>

</table>

<?php
require_once 'classes/Database.php';
echo "<p>Fin de l'exécution.</p>";
?>
