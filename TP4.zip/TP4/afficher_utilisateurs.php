<?php
// afficher_utilisateurs.php
require 'connexion.php'; // Inclut la connexion PDO

try {
    echo "<h2>Liste des Utilisateurs Enregistrés</h2>";

    // 1. Exécuter la requête SELECT (pas besoin de préparer ici, car pas de données utilisateur)
    $resultat = $pdo->query("SELECT id, nom, email FROM utilisateurs ORDER BY id DESC");

    // 2. Récupérer toutes les lignes dans un tableau associatif
    $utilisateurs = $resultat->fetchAll(PDO::FETCH_ASSOC);
    
    if (count($utilisateurs) > 0) {
        // Début du tableau HTML
        echo "<table border='1' style='width: 80%; border-collapse: collapse;'>";
        echo "<tr><th>ID</th><th>Nom</th><th>Email</th></tr>";
        
        // 3. Parcourir le tableau des résultats (chaque $user est une ligne)
        foreach ($utilisateurs as $user) {
            echo "<tr>";
            // Sécurité : htmlspecialchars() est toujours utilisé pour l'affichage
            echo "<td>" . htmlspecialchars($user['id']) . "</td>";
            echo "<td>" . htmlspecialchars($user['nom']) . "</td>";
            echo "<td>" . htmlspecialchars($user['email']) . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p>Aucun utilisateur trouvé dans la base de données.</p>";
    }

} catch (PDOException $e) {
    die("Erreur de lecture des données : " . $e->getMessage());
}
?>