<?php
// login.php
// Nous allons ajouter session_start() et la logique de connexion ici.
?>
<!DOCTYPE html>
<html lang="fr">
<head><title>Connexion Sécurisée</title></head>
<body>
    <h1>Connexion</h1>
    <form action="login.php" method="POST">
        <label for="username">Nom d'utilisateur :</label>
        <input type="text" id="username" name="username" required><br><br>

        <label for="password">Mot de passe :</label>
        <input type="password" id="password" name="password" required><br><br>

        <input type="submit" value="Se connecter">
    </form>
</body>
</html>
<?php
// login.php - Début du f  ichier
session_start(); // **TRÈS IMPORTANT** : Démarre la session

require 'connexion.php'; // Inclut l'objet $pdo

// 1. Vérification de la soumission du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    $message = '';

    // 2. Récupération du hachage dans la base de données (Requête Préparée PDO)
    $sql = "SELECT username, password_hash FROM utilisateurs WHERE username = :username";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':username', $username);
    $stmt->execute();
    
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        // 3. Vérification du mot de passe clair avec le hachage stocké
        if (password_verify($password, $user['password_hash'])) {
            
            // --- Authentification réussie (Phase 3) ---
            $_SESSION['logged_in'] = true;
            $_SESSION['username'] = $user['username'];
            
            // Redirection vers la page protégée
            header('Location: dashboard.php');
            exit;
            // ------------------------------------------

        } else {
            $message = "Nom d'utilisateur ou mot de passe incorrect.";
        }
    } else {
        $message = "Nom d'utilisateur ou mot de passe incorrect.";
    }
}
// Afficher $message dans le HTML pour l'utilisateur
?>