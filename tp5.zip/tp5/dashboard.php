<?php
// dashboard.php
session_start(); // Démarrer la session

// 1. Contrôle d'accès : Vérifier si l'utilisateur est connecté
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    // Si l'utilisateur n'est PAS connecté, on le redirige immédiatement.
    header('Location: login.php');
    exit;
}

// L'utilisateur est connecté, le code de la page peut s'exécuter
$username = $_SESSION['username'];
?>
<!DOCTYPE html>
<html lang="fr">
<head><title>Tableau de Bord Protégé</title></head>
<body>
    <h1>Bienvenue, <?php echo htmlspecialchars($username); ?> !</h1>
    <p>Ceci est une zone protégée, seuls les membres peuvent y accéder.</p>
    <p><a href="logout.php">Se déconnecter</a></p>
</body>
</html>