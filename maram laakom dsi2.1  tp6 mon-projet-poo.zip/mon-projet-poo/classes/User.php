<?php
class User {

    private static function getPDO() {
        return Database::getInstance()->getConnection();
    }

    public static function getAllUsers() {
        $pdo = self::getPDO();
        $stmt = $pdo->prepare("SELECT id, nom, email FROM utilisateurs");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function insertUser($nom, $email) {
        $pdo = self::getPDO();
        $stmt = $pdo->prepare("INSERT INTO utilisateurs (nom, email) VALUES (:nom, :email)");
        $stmt->bindParam(':nom', $nom);
        $stmt->bindParam(':email', $email);
        return $stmt->execute();
    }
}
