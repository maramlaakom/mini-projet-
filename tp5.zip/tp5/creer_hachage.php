<?php
// creer_hachage.php
$mot_de_passe_clair = "MotDePasse123";

// Utilisation de l'algorithme BCRYPT par défaut, sécurisé et salé automatiquement
$hachage = password_hash($mot_de_passe_clair, PASSWORD_DEFAULT);

echo "Mot de passe clair : " . $mot_de_passe_clair . "<br>";
echo "Hachage sécurisé à insérer en DB : " . $hachage;
?>